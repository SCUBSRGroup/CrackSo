#include "p_elf.h"
#include "p_dbg.h"
 int nchains;
unsigned int nbuckets, nrels, relsize, totalrelsize;
Elf32_Addr symtab, syment, strtab, jmprel, hashtable;
unsigned long phdr_addr, dyn_addr, map_addr;


struct link_map *get_linkmap(int pid)
{
	Elf32_Ehdr *ehdr = (Elf32_Ehdr *) malloc(sizeof(Elf32_Ehdr));
	Elf32_Phdr *phdr = (Elf32_Phdr *) malloc(sizeof(Elf32_Phdr));
	Elf32_Dyn *dyn = (Elf32_Dyn *) malloc(sizeof(Elf32_Dyn));
	Elf32_Word got;
	struct link_map *map =
	    (struct link_map *) malloc(sizeof(struct link_map));
	int i = 0;

	ptrace_read(pid, IMAGE_ADDR, ehdr, sizeof(Elf32_Ehdr));
	phdr_addr = IMAGE_ADDR + ehdr->e_phoff;
	printf("phdr_addr\t %p %c%c%c\n", phdr_addr,ehdr->e_ident[0],ehdr->e_ident[1],ehdr->e_ident[2]);
	if(ehdr->e_ident[0]!=0x7f||ehdr->e_ident[1]!='E'||ehdr->e_ident[2]!='L'||ehdr->e_ident[3]!='F'){
		printf("error elf magic pid=%d vaddr=%x\n",pid,IMAGE_ADDR);
		return 0;
	}else{
		printf("****ok magic***************************************************\n");
	}

	ptrace_read(pid, phdr_addr, phdr, sizeof(Elf32_Phdr));
	while (phdr->p_type != PT_DYNAMIC)
		ptrace_read(pid, phdr_addr +=
			    sizeof(Elf32_Phdr), phdr, sizeof(Elf32_Phdr));
	dyn_addr = phdr->p_vaddr;
	printf("dyn_addr\t %p\n", dyn_addr);

	ptrace_read(pid, dyn_addr, dyn, sizeof(Elf32_Dyn));
	while (dyn->d_tag != DT_PLTGOT) {
		ptrace_read(pid, dyn_addr + i * sizeof(Elf32_Dyn), dyn,
			    sizeof(Elf32_Dyn));
		i++;
	}

	got = (Elf32_Word) dyn->d_un.d_ptr;
	got += 4;
	printf("GOT\t\t %p\n", got);

	ptrace_read(pid, got, &map_addr, 4);
	printf("map_addr\t %p\n", map_addr);
	ptrace_read(pid, map_addr, map, sizeof(struct link_map));

	free(ehdr);
	free(phdr);
	free(dyn);

	return map;
}

void get_sym_info(int pid, struct link_map *lm)
{
	Elf32_Dyn *dyn = (Elf32_Dyn *) malloc(sizeof(Elf32_Dyn));
	unsigned long dyn_addr;
	puts("[get_sym_info]on");

	dyn_addr = (unsigned long) lm->l_ld;
	symtab = syment = strtab = hashtable = jmprel = totalrelsize = relsize = nchains=nrels=0;

	ptrace_read(pid, dyn_addr, dyn, sizeof(Elf32_Dyn));
	while (dyn->d_tag != DT_NULL) {
		switch (dyn->d_tag) {
		case DT_SYMTAB:
			//puts("DT_SYMTAB");
			symtab = dyn->d_un.d_ptr;
			break;
		case DT_SYMENT:
			//puts("DT_SYMENT");
			syment = dyn->d_un.d_val;
			break;
		case DT_STRTAB:
			//puts("DT_STRTAB");
			strtab = dyn->d_un.d_ptr;
			break;
		case DT_HASH:
			//puts("DT_HASH");
			hashtable = dyn->d_un.d_ptr + lm->l_addr;
			ptrace_read(pid, dyn->d_un.d_ptr + lm->l_addr,
				    &nbuckets, sizeof(nbuckets));
			ptrace_read(pid, dyn->d_un.d_ptr + lm->l_addr + 4,
				    &nchains, sizeof(nchains));
			break;
		case DT_JMPREL:
			//puts("DT_JMPREL");
			jmprel = dyn->d_un.d_ptr;
			break;
		case DT_PLTRELSZ:
			//puts("DT_PLTRELSZ");
			totalrelsize = dyn->d_un.d_val;
			break;
		case DT_RELAENT:
			//puts("DT_RELAENT");
			relsize = dyn->d_un.d_val;
			break;
		case DT_RELENT:
			//puts("DT_RELENT");
			relsize = dyn->d_un.d_val;
			break;
		default:
			//puts("default");
			break;
		}

		ptrace_read(pid, dyn_addr +=
			    sizeof(Elf32_Dyn), dyn, sizeof(Elf32_Dyn));
	}

	if(relsize)nrels = totalrelsize / relsize;

	free(dyn);
	puts("[get_sym_info]off");
}


unsigned long find_symbol(int pid, struct link_map *map, char *sym_name,
			  char mode)
{
	printf("[find_symbol] in\n");
	struct link_map *lm =
	    (struct link_map *) malloc(sizeof(struct link_map));
	unsigned long sym_addr;
	char *str;

	if (mode == 'h')
		sym_addr = find_symbol_in_linkmap_hash(pid, map, sym_name);
	else
		sym_addr = find_symbol_in_linkmap(pid, map, sym_name);

	if (sym_addr)
		return sym_addr;

	if (!map->l_next)
		return 0;

	ptrace_read(pid, (unsigned long) map->l_next, lm,
		    sizeof(struct link_map));
	if (mode == 'h')
		sym_addr = find_symbol_in_linkmap_hash(pid, lm, sym_name);
	else
		sym_addr = find_symbol_in_linkmap(pid, lm, sym_name);

	while (!sym_addr && lm->l_next) {
		printf("lmnext=%x\n", lm->l_next);
		ptrace_read(pid, (unsigned long) lm->l_next, lm,
			    sizeof(struct link_map));

		str = ptrace_readstr(pid, (unsigned long) lm->l_name);
		if (str[0] == '\0')
			continue;
		    int i;
    for(i = 0; str[i] != 0; i++){
        if(isprint(str[i])){
            printf("%c",str[i]);
		}
	}
		printf("\n");
		free(str);

		if (mode == 'h')
			sym_addr =
			    find_symbol_in_linkmap_hash(pid, lm, sym_name);
		else
			sym_addr =
			    find_symbol_in_linkmap(pid, lm, sym_name);

		if (sym_addr)
			break;
	}
	printf("[find_symbol] off\n");
	return sym_addr;
}


unsigned long find_symbol_in_linkmap(int pid, struct link_map *lm,
				     char *sym_name)
{
	Elf32_Sym *sym = (Elf32_Sym *) malloc(sizeof(Elf32_Sym));
	int i;
	char *str;
	unsigned long ret=0;


	get_sym_info(pid, lm);
	printf("[find_symbol_in_linkmap]in\n");
	if(symtab==0)return ret;
	int finded=0;
	
	for (i = 0; i < 10000; i++) {
		ptrace_read(pid, symtab + i * sizeof(Elf32_Sym), sym,
			    sizeof(Elf32_Sym));

		if (!sym->st_name && !sym->st_size && !sym->st_value)
			break;

/*		if (ELF32_ST_TYPE(sym->st_info) != STT_FUNC)
			continue;
*/
		str = (char *) ptrace_readstr(pid, strtab + sym->st_name);
		if(isprint(str[0])){
			puts(str);
			   
			if (strcmp(str, sym_name) == 0) {
				printf("!!!!strcmp=0 [%s][%s]\n",str,sym_name);
				free(str);
				str =
					ptrace_readstr(pid,
						   (unsigned long) lm->l_name);
				printf("lib name [%s]\n", str);
				free(str);
				finded = 1;
				break;
			}
		}
		free(str);
	}



	
	if(finded)	ret = lm->l_addr + sym->st_value;
	

	free(sym);
	printf("[find_symbol_in_linkmap]off\n",ret);
	return ret;
}


unsigned long find_sym_in_rel(int pid, char *sym_name)
{
	Elf32_Rel *rel = (Elf32_Rel *) malloc(sizeof(Elf32_Rel));
	Elf32_Sym *sym = (Elf32_Sym *) malloc(sizeof(Elf32_Sym));
	int i;
	char *str;
	unsigned long ret;

	get_dyn_info(pid);
	for (i = 0; i < nrels; i++) {
		ptrace_read(pid,
			    (unsigned long) (jmprel +
					     i * sizeof(Elf32_Rel)), rel,
			    sizeof(Elf32_Rel));
		if (ELF32_R_SYM(rel->r_info)) {
			ptrace_read(pid,
				    symtab +
				    ELF32_R_SYM(rel->r_info) *
				    sizeof(Elf32_Sym), sym,
				    sizeof(Elf32_Sym));
			str = ptrace_readstr(pid, strtab + sym->st_name);
			if (strcmp(str, sym_name) == 0) {
				free(str);
				break;
			}
			free(str);
		}
	}

	if (i == nrels)
		ret = 0;
	else
		ret = rel->r_offset;

	free(rel);

	return ret;
}


void get_dyn_info(int pid)
{
	Elf32_Dyn *dyn = (Elf32_Dyn *) malloc(sizeof(Elf32_Dyn));
	int i = 0;

	ptrace_read(pid, dyn_addr + i * sizeof(Elf32_Dyn), dyn,
		    sizeof(Elf32_Dyn));
	i++;
	while (dyn->d_tag) {
		switch (dyn->d_tag) {
		case DT_SYMTAB:
			//puts("DT_SYMTAB");
			symtab = dyn->d_un.d_ptr;
			break;
		case DT_STRTAB:
			strtab = dyn->d_un.d_ptr;
			//puts("DT_STRTAB");
			break;
		case DT_JMPREL:
			jmprel = dyn->d_un.d_ptr;
			//puts("DT_JMPREL");
			printf("jmprel\t %p\n", jmprel);
			break;
		case DT_PLTRELSZ:
			totalrelsize = dyn->d_un.d_val;
			//puts("DT_PLTRELSZ");
			break;
		case DT_RELAENT:
			relsize = dyn->d_un.d_val;
			//puts("DT_RELAENT");
			break;
		case DT_RELENT:
			relsize = dyn->d_un.d_val;
			//puts("DT_RELENT");
			break;
		}

		ptrace_read(pid, dyn_addr + i * sizeof(Elf32_Dyn), dyn,
			    sizeof(Elf32_Dyn));
		i++;
	}

	nrels = totalrelsize / relsize;

	free(dyn);
}


void print_symtab(int pid)
{
	Elf32_Sym *sym = (Elf32_Sym *) malloc(sizeof(Elf32_Sym));
	int i;
	char *str;

	for (i = 0; i < nchains; i++) {
		ptrace_read(pid, symtab + i * sizeof(Elf32_Sym), sym,
			    sizeof(Elf32_Sym));
		str = ptrace_readstr(pid, strtab + sym->st_name);
		printf("%d\t %s\n", i, str);
		free(str);
	}

	free(sym);
}

unsigned long elf_hash(const unsigned char *name)
{
	unsigned long h = 0, g;

	while (*name) {
		h = (h << 4) + *name++;
		if (g = h & 0xf0000000)
			h ^= g >> 24;
		h &= ~g;
	}

	return h;
}


unsigned long find_symbol_in_linkmap_hash(int pid, struct link_map *lm,
					  char *sym_name)
{
	Elf32_Sym *sym = (Elf32_Sym *) malloc(sizeof(Elf32_Sym));
	char *str;
	unsigned long ret;
	unsigned long hash;
	Elf32_Word *pChains, *pBuckets;
	Elf32_Word bucket, chain, nextchain;
	int found;

	puts("[mode hash]");
	get_sym_info(pid, lm);

	pBuckets = (Elf32_Word *) hashtable + 2;
	pChains = (Elf32_Word *) hashtable + 2 + nbuckets;
	hash = elf_hash(sym_name) % nbuckets;

	ptrace_read(pid, (unsigned long) (pBuckets + hash), &bucket,
		    sizeof(bucket));
	nextchain = bucket;
	found = 0;
	while ((chain = nextchain) != STN_UNDEF) {
		//printf("%ul = %ul?\n", syment, sizeof(Elf32_Sym));
		ptrace_read(pid, symtab + chain * syment, sym,
			    sizeof(Elf32_Sym));
		ptrace_read(pid, (unsigned long) (pChains + chain),
			    &nextchain, sizeof(nextchain));

		if (!sym->st_name || !sym->st_size || !sym->st_value)
			continue;

/*		if (ELF32_ST_TYPE(sym->st_info) != STT_FUNC)
			continue;
*/
		str = (char *) ptrace_readstr(pid, strtab + sym->st_name);
		if (strcmp(str, sym_name) == 0) {
			free(str);
			str =
			    ptrace_readstr(pid,
					   (unsigned long) lm->l_name);
			printf("lib name [%s]\n", str);
			free(str);
			found = 1;
			break;
		}
		free(str);
	}



	if (found == 0)
		ret = 0;
	else
		ret = lm->l_addr + sym->st_value;

	free(sym);

	return ret;
}


void print_symbol_all(int pid, struct link_map *map)
{
	struct link_map *lm =
	    (struct link_map *) malloc(sizeof(struct link_map));
	char *str;


	str = ptrace_readstr(pid, (unsigned long) map->l_name);
	printf("[%s]\n", str);
	free(str);
	get_sym_info(pid, map);
	print_symtab(pid);

	if (!map->l_next)
		return;

	ptrace_read(pid, (unsigned long) map->l_next, lm,
		    sizeof(struct link_map));
	while (lm->l_next) {
		ptrace_read(pid, (unsigned long) lm->l_next, lm,
			    sizeof(struct link_map));

		//str = ptrace_readstr(pid, (unsigned long) lm->l_name);
		//printf("[%s]\n", str);
		//free(str);
		get_sym_info(pid, lm);
		print_symtab(pid);
	}

}
