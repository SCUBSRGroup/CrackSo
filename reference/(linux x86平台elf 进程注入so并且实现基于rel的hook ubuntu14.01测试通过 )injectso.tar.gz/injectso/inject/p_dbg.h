#include <sys/ptrace.h>
#include <wait.h>
#include <sys/user.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define NULL 0

void ptrace_attach(int pid);
void ptrace_cont(int pid);
void ptrace_detach(int pid);
void ptrace_write(int pid, unsigned long addr, void *vptr, int len);
void ptrace_read(int pid, unsigned long addr, void *vptr, int len);
char * ptrace_readstr(int pid, unsigned long addr);
void ptrace_readreg(int pid, struct user_regs_struct *regs);
void ptrace_writereg(int pid, struct user_regs_struct *regs);
void * ptrace_push(int pid, void *paddr, int size);
void ptrace_call(int pid, unsigned long addr);
void restart_syscall(void);

