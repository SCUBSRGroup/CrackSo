#include <elf.h>
#include <link.h>

#define IMAGE_ADDR 0x08048000

struct link_map * get_linkmap(int pid);
void get_sym_info(int pid, struct link_map *lm);
void get_dyn_info(int pid);
void get_dyn_info2(int pid,int dynaddr);
unsigned long  find_symbol(int pid, struct link_map *map, char *sym_name, char mode);
unsigned long  find_symbol_in_linkmap(int pid, struct link_map *lm, char *sym_name);
unsigned long  find_symbol_in_linkmap_hash(int pid, struct link_map *lm, char *sym_name);
unsigned long find_sym_in_rel2(int pid, char *sym_name,int dynaddr);
unsigned long find_sym_in_rel(int pid, char *sym_name);
void print_symtab(int pid);
unsigned long elf_hash(const unsigned char *name);
void print_symbol_all(int pid, struct link_map *map);
